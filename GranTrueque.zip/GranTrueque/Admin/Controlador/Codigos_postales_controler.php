<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backoffice</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/backoffice.css">
</head>
<body>
    <?php

        class Consultas {

             private $db;

            public function __construct(){
                 require_once ("../Modelo/conexiondb.php");
                 require_once ("../Modelo/Codigos_postales_model.php");
                 require_once ("../Vista/Codigos_postales_view.php");
                 $this->db = Conectar::conexion();
    }
}

    ?>

</body>
</html>

    