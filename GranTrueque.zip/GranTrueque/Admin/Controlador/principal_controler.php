
    <?php
                 
                 if (isset($_POST['crear'])){
                     echo "se ha pulsado el botón categorías";
                 } if (isset($_POST['crear_cp'])){
                    require ("../Modelo/codigos_postales_modelo.php");
                    $codigo_postal = new Codigo_Postal();
                    $codigo_postal->Alta_Codigo_Postal();
                    header ("Location:../Vista/codigos_postales_view.php");
               
                  } else if (isset($_POST['menu_principal_cp'])){
                    require_once ("../Vista/backoffice_view.php");
               
                  } else if (isset($_POST['crear_categoria'])){
                     require ("../Modelo/categorias_modelo.php");
                     $categoria = new Categoria();
                     $categoria->Alta_Categoria();
                     header ("Location:../Vista/categorias_view.php");
                
                  } else if (isset($_POST['menu_principal_categoria'])){ 
                     require_once ("../Vista/backoffice_view.php"); 
                  
                  } else if (isset($_POST['devolucion'])){
                     require ("../Modelo/devolucion_modelo.php");
                     $devolucion = new Devoluciones ();
                     $devolucion->Devolver_Importe();
                     //require_once ("../Vista/backoffice_view.php"); 
                
                  } else {
                    require_once ("../Vista/backoffice_view.php");
                  } 

    ?>
