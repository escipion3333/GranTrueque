<?php
    // Realizamos la conexión
    Class Categoria{

        private $descripcion_categoria;

        public function Alta_Categoria (){

            require("conexionPDO_modelo.php");

        // Obtenemos los datos del formulario

        $this->descripcion_categoria = htmlentities(addslashes($_POST["categoria"]));

        echo $this->descripcion_categoria;

        $consulta = "INSERT INTO Categorías (DescripcionCategoria)
                VALUES (:descripcion_categoria)";
                $resultado=$conexion->prepare($consulta);
                $resultado->execute (array(":descripcion_categoria"=>$this->descripcion_categoria));     

      }
    }
    
?>