<?php
    // Realizamos la conexión
    Class Codigo_Postal{

        private $codigo_postal;
        private $localidad;
        private $provincia;

        public function Alta_Codigo_Postal(){

            require("conexionPDO_modelo.php");

        // Obtenemos los datos del formulario

        $this->codigo_postal = htmlentities(addslashes($_POST["codigo_postal"]));
        $this->localidad = htmlentities(addslashes($_POST["localidad"]));
        $this->provincia = htmlentities(addslashes($_POST["provincia"]));   

        $consulta = "INSERT INTO CodigosPostales (CodigoPostal, Localidad, Provincia)
                VALUES (:codigo_postal, :localidad, :provincia)";
                $resultado=$conexion->prepare($consulta);
                $resultado->execute (array(":codigo_postal"=>$this->codigo_postal, 
                ":localidad" =>$this->localidad,
                ":provincia"=>$this->provincia));
            

      }
    }
    
?>