<?php
    class Conectar {
      public static function conexion (){

        try {

            $db_host = "localhost";
            $db_nombre = "GranTrueque";
            $db_usuario = "root";
            $db_contra = "";
    
            $conexion = mysqli_connect ("$db_host","$db_usuario","$db_contra","$db_nombre");     // Creamos conexión de base de datos
            mysqli_set_charset($conexion,"utf8");
            
            // echo "Conexión establecida con éxito";

        } catch (Exception $e){
            echo "Error coneión" . $e->getLine();
            } 

        return $conexion;    
    
      } 
    }


?>