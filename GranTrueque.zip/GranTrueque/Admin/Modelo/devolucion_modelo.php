<?php
    // Realizamos la conexión
    Class Devoluciones{

        private $usuario;
        private $importe;

        public function Devolver_Importe(){

            require("conexionPDO_modelo.php");

        // Obtenemos los datos del formulario

        $this->usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
        $this->importe = htmlentities(addslashes($_POST["importe"]));

        echo "Información para la pasarela de pago. Devolución al usuario $this->usuario 
       por un importe de " . $this->importe ;
            

      }
    }
    
?>