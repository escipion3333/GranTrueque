<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backoffice</title>
    <link rel="stylesheet" href="../../Vista/bootstr./.ap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Vista/css/usuarios.css">
</head>
<body>
    <section>
        <!-- Creamos las cabeceras -->
        <h1 class="cabecera centrar">Gran Trueque</h1>
        </div>
    </section>

    <section>
        <nav>
            <!-- Creamos el menú de navegación -->

            <a href="../Vista/categorias_view.php" class="menu-navegacion">Categorías</a>
            <a href="../Vista/gestion_pedidos_view.php" class="menu-navegacion">Gestión de pedidos</a>
            <a href="../Vista/codigos_postales_view.php" class="menu-navegacion">Códigos postales</a>
                  
        </nav>
    </section>
</body>
</html>