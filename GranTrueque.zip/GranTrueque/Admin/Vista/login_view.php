<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Vista/css/usuarios.css">
</head>
<body>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Gestion Usuarios</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo pdrás crear tu cuenta de usuario</p>
                <p class="text-danger small pt-0 mt-0">Todos los campos son obligatorios</p>
                
                <form action = "login_controlador.php" method="POST">
                    <div class="row form-group">
                        <label for="nombre_usuario" class="col-form-label col-md-4">Nombre Usuario:</label>
                        <div class="col-md-8">
                             <input type="text" name="nombre_usuario" value="" id="nombre_usuario" class="form-control"> 
                        </div>              
                    </div>

                    <div class="row form-group">
                        <label for="clave" class="col-form-label col-md-4">Contraseña</label>
                        <div class="col-md-8">
                             <input type="password" name="clave" value="" id="clave" class="form-control"> 
                        </div>              
                    </div>
                
                    <div class="row">
                        <div class="col">
                        <button type="submit" name="login" class="btn btn-info">Login</button>
                        </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>