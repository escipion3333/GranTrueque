<?php

    session_start(); 

    if (isset($_SESSION["usuario"])){
    
        require_once ("../Vista/anuncios_view.php");
        
        if (isset($_POST['crear'])){

        require_once ("../Vista/anuncios_view.php");

            // Si se ha pulsado el botón login compueba si el usuario existe

        require_once("../Modelo/gestionar_anuncios_modelo.php");

            $anuncio = new Anuncio();
            $anuncio->Crear_Anuncio();
        } 

    } else {
        header ("location:../index.php");      
      }   

?>