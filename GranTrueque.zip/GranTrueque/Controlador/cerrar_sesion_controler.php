<?php

    require_once("../Vista/cerrar_sesion_view.php");
    require_once("../Modelo/gestionar_usuario_modelo.php");

    session_start();

    if (isset($_POST['cerrar'])){

        // Si se ha pulsado el botón login compueba si el usuario existe

        if (isset($_SESSION["usuario"])){

            $login = new Usuario();
            $login->Cerrar_Sesion();
            header ("location:../index.php");
            

        }else {
            echo "El usuario no está logado";
            header ("location:../index.php");

        } 
    }
    

?>