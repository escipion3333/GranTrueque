<?php

    require_once("../Vista/crear_usuario_view.php");

    if (isset($_POST['crear'])){

        // Si se ha pulsado el botón login compueba si el usuario existe

       require_once("../Modelo/gestionar_usuario_modelo.php");

        $usuario = new Usuario();
        $usuario->Crear_Usuario();
    }


?>