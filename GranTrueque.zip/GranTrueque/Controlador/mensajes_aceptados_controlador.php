<?php

    session_start();  
    if (!isset($_SESSION["usuario"])){
        header ("Location:../index.php");
    } else {
        // Si el usuario está logado muestra los datos
        require ("../Modelo/mensaje_modelo.php");

        $mensaje = new Mensaje ();
        $mensaje->Ver_Propuestas_Aceptadas();
        $codigo_mensaje = $mensaje->get_Codigo_Mensaje();
        $ofrezco_origen = $mensaje->get_Ofrezco_Origen();
        $valor_origen = $mensaje->get_Valor_Origen();
        $descripcion_mensaje_anunciante = $mensaje->get_Descripcion_Mensaje_Anunciante();
        $valor_anunciante = $mensaje->get_Valor_Anunciante();
        $ofrezco_origen;
        $valor_origen;
        $descripcion_mensaje_anunciante;
        $valor_anunciante;

        require ("../Vista/mensajes_aceptados_view.php");
        
        if (isset($_POST["menu_principal_aceptados"])){
            header ("Location:../index.php");
        }  if (isset($_POST["pagar"])){
        
            require ("../Modelo/pagos_modelo.php");
            $pago = new Pagos();
            $pago->Pagar_Origen();
            header ("Location: ../index.php"); 
           
            }

 

    }
      
    

?>