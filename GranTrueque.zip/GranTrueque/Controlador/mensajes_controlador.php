<?php

    session_start();  
    if (isset($_SESSION["usuario"])){
    
        // Si el usuario está logado muestra los datos
        require ("../Modelo/mensaje_modelo.php");

        $mensaje = new Mensaje ();
        $mensaje->Mostrar_Propuesta();
        $codigo_mensaje = $mensaje->get_Codigo_Mensaje();
        $codigo_usuario_origen = $mensaje->get_Codigo_Usuario_Origen();
        $codigo_anuncio_origen = $mensaje->get_Codigo_Anuncio_Origen();
        $ofrezco_origen = $mensaje->get_Ofrezco_Origen();
        $valor_origen = $mensaje->get_Valor_Origen();
        $imagen_origen = $mensaje->get_Imagenes_Origen();
        $ruta_origen = "Controlador/" . $imagen_origen;
        $email_origen = $mensaje->get_Email_Origen();
       
        require ("../Vista/propuesta_cambio_view.php");
        if (isset($_POST["rechazar"])){
            $mensaje = new Mensaje ();
            $mensaje->Rechazar_Mensaje();
        } else if (isset($_POST["pago"])){
            require ("../Modelo/pagos_modelo.php");
            $mensaje = new Mensaje();
            $mensaje->Aceptar_Propuesta ();
            $pago = new Pagos();
            $pago->Pago_Anunciante();
            header ("Location: ../index.php");

            }


    };   
    

?>