<?php

    session_start();  
    if (isset($_SESSION["usuario"])){
    
        // Si el usuario está logado muestra los datos

        require_once("../Modelo/gestionar_usuario_modelo.php");

        $login = new Usuario();
        $login->Buscar_Usuario();
        $usuario = $login->get_Usuario();
        $clave = $login->get_Clave();
        $email = $login->get_Email();
        $codigo_postal = $login->get_Codigo_Postal();
        $localidad = $login->get_Localidad();
        $provincia = $login->get_Provincia();
        
        require_once("../Vista/mi_cuenta_view.php");

        // Si se ha pulsado sobre modificar
        
        if (isset($_POST['modificar'])){
            require_once("../Modelo/gestionar_usuario_modelo.php");

            $usuario = new Usuario();
            $usuario->Modificar_Usuario();
        }

        if (isset($_POST['baja'])){
            $usuario = new Usuario();
            $usuario->Baja_Usuario();
        }

    } else {
        header ("location:../index.php"); 
    
      }
    
    


?>