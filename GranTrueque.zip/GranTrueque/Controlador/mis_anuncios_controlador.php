<?php

    session_start();  
    if (isset($_SESSION["usuario"])){
    
        // Si el usuario está logado muestra los datos

        require ("../Modelo/gestionar_anuncios_modelo.php");

        $anuncio = new Anuncio();
        $anuncio->Buscar_Anuncio();
        $nombre_usuario = $anuncio->get_Nombre_usuario();
        $ofrezco = $anuncio->get_Ofrezco();
        $descripcion = $anuncio->get_Descripcion();
        $valor = $anuncio->get_Valor();
        $categoria = $anuncio->get_Categoria();
        $imagenes = $anuncio->get_Imagenes();

        
        require ("../Vista/mis_anuncios_view.php");
        
        // Si se ha pulsado sobre modificar
        
        if (isset($_POST['modificar'])){
            
            require_once("../Modelo/gestionar_anuncios_modelo.php");

            $anuncio = new Anuncio();
            $anuncio->Modificar_Anuncio();
        }
        
        if (isset($_POST['borrar'])){
            $anuncio = new Anuncio();
            $anuncio->Borrar_Anuncio();
        }

    } else {
        header ("location:../index.php");
    
      }
    
    


?>