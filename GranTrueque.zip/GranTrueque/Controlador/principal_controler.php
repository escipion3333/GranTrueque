<!DOCTYPE html>  
<meta charset ="utf-8">
<html lang="es">
<head>
<title>    </title>
   <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
   <link rel="stylesheet" href="../Vista/assets/css/main.css" />
</head>

<body>

<?php if (isset($_POST["anuncio1"])){
  
  
     require "../Modelo/gestionar_anuncios_modelo.php";
                 
     $anuncios = new Anuncio();
     $anuncios-> Ver_Anuncio("anuncio1"); 
     $codigo_anuncio = $anuncios->get_Codigo_Anuncio();
     $ofrezco = $anuncios->get_Ofrezco();
     $descripcion = $anuncios->get_Descripcion();
     $valor = $anuncios->get_Valor();
     $imagen = $anuncios->get_Imagen();
     $ruta = "../Controlador/" . $imagen;
     $codigo_usuario = $anuncios->get_Codigo_usuario();
     $email = $anuncios->get_Email();

     require "../Vista/ver_anuncio_view.php";   

   }  else if (isset($_POST["anuncio2"])){
      require "../Modelo/gestionar_anuncios_modelo.php";
      $anuncios = new Anuncio();
      $anuncios-> Ver_Anuncio ("anuncio2"); 
      $codigo_anuncio = $anuncios->get_Codigo_Anuncio();
      $ofrezco = $anuncios->get_Ofrezco();
      $descripcion = $anuncios->get_Descripcion();
      $valor = $anuncios->get_Valor();
      $imagen = $anuncios->get_Imagen();
      $ruta = "../Controlador/" . $imagen;
      $codigo_usuario = $anuncios->get_Codigo_usuario();
      $email = $anuncios->get_Email();
      require "../Vista/ver_anuncio_view.php";  

   }  else if (isset($_POST["anuncio3"])){

      require "../Modelo/gestionar_anuncios_modelo.php";
      $anuncios = new Anuncio();
      $anuncios-> Ver_Anuncio("anuncio3");
      $codigo_anuncio = $anuncios->get_Codigo_Anuncio(); 
      $ofrezco = $anuncios->get_Ofrezco();
      $descripcion = $anuncios->get_Descripcion();
      $valor = $anuncios->get_Valor();
      $imagen = $anuncios->get_Imagen();
      $ruta = "../Controlador/" . $imagen;
      $codigo_usuario = $anuncios->get_Codigo_usuario();
      $email = $anuncios->get_Email();
      require "../Vista/ver_anuncio_view.php";  
      } else if (isset($_POST["anuncio4"])){

         require "../Modelo/gestionar_anuncios_modelo.php";
         $anuncios = new Anuncio();
         $anuncios-> Ver_Anuncio("anuncio4"); 
         $ofrezco = $anuncios->get_Ofrezco();
         $codigo_anuncio = $anuncios->get_Codigo_Anuncio();
         $descripcion = $anuncios->get_Descripcion();
         $valor = $anuncios->get_Valor();
         $imagen = $anuncios->get_Imagen();
         $ruta = "../Controlador/" . $imagen;
         $codigo_usuario = $anuncios->get_Codigo_usuario();
         $email = $anuncios->get_Email();
         require "../Vista/ver_anuncio_view.php";  
         }
         else if (isset($_POST["anuncio5"])){
            require "../Modelo/gestionar_anuncios_modelo.php";
            $anuncios = new Anuncio();
            $anuncios-> Ver_Anuncio("anuncio5");
            $codigo_anuncio = $anuncios->get_Codigo_Anuncio(); 
            $ofrezco = $anuncios->get_Ofrezco();
            $descripcion = $anuncios->get_Descripcion();
            $valor = $anuncios->get_Valor();
            $imagen = $anuncios->get_Imagen();
            $ruta = "../Controlador/" . $imagen;
            $codigo_usuario = $anuncios->get_Codigo_usuario();
            $email = $anuncios->get_Email();
            require "../Vista/ver_anuncio_view.php";  
            }
            else if (isset($_POST["anuncio6"])){
               require "../Modelo/gestionar_anuncios_modelo.php";
               $anuncios = new Anuncio();
               $codigo_anuncio = $anuncios->get_Codigo_Anuncio();
               $anuncios-> Ver_Anuncio("anuncio6"); 
               $ofrezco = $anuncios->get_Ofrezco();
               $descripcion = $anuncios->get_Descripcion();
               $valor = $anuncios->get_Valor();
               $imagen = $anuncios->get_Imagen();
               $ruta = "../Controlador/" . $imagen;
               $codigo_usuario = $anuncios->get_Codigo_usuario();
               $email = $anuncios->get_Email();
               require "../Vista/ver_anuncio_view.php";  
               }else if (isset($_POST["anuncio7"])){
                  require "../Modelo/gestionar_anuncios_modelo.php";
                  $anuncios = new Anuncio();
                  $anuncios-> Ver_Anuncio("anuncio7");
                  $codigo_anuncio = $anuncios->get_Codigo_Anuncio(); 
                  $ofrezco = $anuncios->get_Ofrezco();
                  $descripcion = $anuncios->get_Descripcion();
                  $valor = $anuncios->get_Valor();
                  $imagen = $anuncios->get_Imagen();
                  $ruta = "../Controlador/" . $imagen;
                  $codigo_usuario = $anuncios->get_Codigo_usuario();
                  $email = $anuncios->get_Email();
                  require "../Vista/ver_anuncio_view.php";  
                  }else if (isset($_POST["anuncio8"])){
                     require "../Modelo/gestionar_anuncios_modelo.php";
                     $anuncios = new Anuncio();
                     $anuncios-> Ver_Anuncio("anuncio8");
                     $codigo_anuncio = $anuncios->get_Codigo_Anuncio(); 
                     $ofrezco = $anuncios->get_Ofrezco();
                     $descripcion = $anuncios->get_Descripcion();
                     $valor = $anuncios->get_Valor();
                     $imagen = $anuncios->get_Imagen();
                     $ruta = "../Controlador/" . $imagen;
                     $codigo_usuario = $anuncios->get_Codigo_usuario();
                     $email = $anuncios->get_Email();
                     require "../Vista/ver_anuncio_view.php";  
                     }else if (isset($_POST["anuncio9"])){
                        require "../Modelo/gestionar_anuncios_modelo.php";
                        $anuncios = new Anuncio();
                        $anuncios-> Ver_Anuncio("anuncio9");
                        $codigo_anuncio = $anuncios->get_Codigo_Anuncio(); 
                        $codigo_usuario = $anuncios->get_Codigo_usuario();
                        $ofrezco = $anuncios->get_Ofrezco();
                        $descripcion = $anuncios->get_Descripcion();
                        $valor = $anuncios->get_Valor();
                        $imagen = $anuncios->get_Imagen();
                        $ruta = "../Controlador/" . $imagen;
                        $codigo_usuario = $anuncios->get_Codigo_usuario();
                        $email = $anuncios->get_Email();
                        require "../Vista/ver_anuncio_view.php";  
                        } else if (isset($_POST["menu_principal2"])){
                           header ("Location:../index.php");
           
                        }else if (isset($_POST["trueque"])){

                           require ("../Modelo/trueque_modelo.php");
                           $trueque = new Trueque();
                           $trueque->Buscar_Anuncios();
                           $codigo_anuncio = $trueque->get_Codigo_Anuncio();
                           $ofrezco = $trueque->get_Ofrezco();
                           $valor = $trueque->get_Valor();
                           require ("../Modelo/mensaje_modelo.php");
                           $mensaje = new Mensaje();
                           $mensaje->Nuevo_Mensaje();
                           header ("Location:../index.php");               
                        } 
                        else {
         
                         header ("location=index.php");

         require "Modelo/gestionar_anuncios_modelo.php";


         $anuncios = new Anuncio();
         $anuncios->Menu_Principal();
      
       //  Bloque anuncio1;
         $codigo_anuncio1=$anuncios->get_Codigo_anuncio();
         $imagen1 = $anuncios->get_Imagen1();
         $ruta1 = "Controlador/" . $imagen1;
         $ofrezco1 = $anuncios->get_Ofrezco1();
         $descripcion1 = $anuncios->get_Descripcion1();

      // Bloque anuncio2
   
         $codigo_anuncio2=$anuncios->get_Codigo_anuncio2();
         $imagen2 = $anuncios->get_Imagen2();
         $ruta2 = "Controlador/" . $imagen2;
         $ofrezco2 = $anuncios->get_Ofrezco2();
         $descripcion2= $anuncios->get_Descripcion2();

         // Bloque anuncio3
         $codigo_anuncio3=$anuncios->get_Codigo_anuncio3();
         $imagen3 = $anuncios->get_Imagen3();
         $ruta3 = "Controlador/" . $imagen3;
         $ofrezco3 = $anuncios->get_Ofrezco3();
         $descripcion3= $anuncios->get_Descripcion3();

         // Bloque anuncio4
         $codigo_anuncio4=$anuncios->get_Codigo_anuncio4();
         $imagen4 = $anuncios->get_Imagen4();
         $ruta4 = "Controlador/" . $imagen4;
         $ofrezco4 = $anuncios->get_Ofrezco4();
         $descripcion4= $anuncios->get_Descripcion4();

         // Bloque anuncio5
         $codigo_anuncio5=$anuncios->get_Codigo_anuncio5();
         $imagen5 = $anuncios->get_Imagen5();
         $ruta5 = "Controlador/" . $imagen5;
         $ofrezco5 = $anuncios->get_Ofrezco5();
         $descripcion5= $anuncios->get_Descripcion5();

         // Bloque anuncio6
         $codigo_anuncio6=$anuncios->get_Codigo_anuncio6();
         $imagen6 = $anuncios->get_Imagen6();
         $ruta6 = "Controlador/" . $imagen6;
         $ofrezco6 = $anuncios->get_Ofrezco6();
         $descripcion6= $anuncios->get_Descripcion6();

         // Bloque anuncio7
         $codigo_anuncio7=$anuncios->get_Codigo_anuncio7();
         $imagen7 = $anuncios->get_Imagen7();
         $ruta7 = "Controlador/" . $imagen7;
         $ofrezco7 = $anuncios->get_Ofrezco7();
         $descripcion7= $anuncios->get_Descripcion7();

         // Bloque anuncio8
         $codigo_anuncio8=$anuncios->get_Codigo_anuncio8();
         $imagen8 = $anuncios->get_Imagen8();
         $ruta8 = "Controlador/" . $imagen8;
         $ofrezco8 = $anuncios->get_Ofrezco8();
         $descripcion8= $anuncios->get_Descripcion8();    
         
         // Bloque anuncio9
         $codigo_anuncio9=$anuncios->get_Codigo_anuncio9();
         $imagen9 = $anuncios->get_Imagen9();
         $ruta9 = "Controlador/" . $imagen9;
         $ofrezco9 = $anuncios->get_Ofrezco9();
         $descripcion9= $anuncios->get_Descripcion9(); 

            // Buscamos si hay algún filtro en los anuncios

         require_once "Vista/principal_view.php"; 
      }   
     //    require "Vista/ver_anuncio_view.php";
      
     //    }

   //      echo $s;
      
 /*        if (isset($_POST["anuncio1"])){
  
           require "../Modelo/gestionar_anuncios_modelo.php";
                 
           $anuncios = new Anuncio();
           $anuncios-> Ver_Anuncio1(); 
           $ofrezco = $anuncios->get_Ofrezco();
           $descripcion = $anuncios->get_Descripcion();
           $valor = $anuncios->get_Valor();
           $imagen = $anuncios->get_Imagen();
           $ruta = "Controlador/" . $imagen;

       //    header ("location=../index");
           require "../Vista/ver_anuncio_view.php";   
         } */

   
       
?>

         <script src="Vista/assets/js/jquery.min.js"></script>
			<script src="Vista/assets/js/jquery.dropotron.min.js"></script>
			<script src="Vista/assets/js/browser.min.js"></script>
			<script src="Vista/assets/js/breakpoints.min.js"></script>
			<script src="Vista/assets/js/util.js"></script>
			<script src="Vista/assets/js/main.js"></script>


</body>
</html>

