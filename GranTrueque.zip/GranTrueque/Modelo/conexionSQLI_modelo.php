<?php

    $host = "localhost";
    $nombre = "GranTrueque";
    $usuario = "root";
    $contra = "";

    $conexion = mysqli_connect($host, $usuario, $contra, $nombre);

    if (mysqli_connect_errno()){
        echo "Fallo al conectar";
        exit ();
    }

    mysqli_set_charset($conexion,"utf8");
?>