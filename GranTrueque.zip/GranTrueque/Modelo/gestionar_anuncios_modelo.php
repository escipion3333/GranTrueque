<?php
    // Realizamos la conexión
    Class Anuncio{

        private $codigo_anuncio;
        private $nombre_usuario;
        private $codigo_anuncio1;
        private $ofrezco;
        private $valor;
        private $categoria;
        private $descripcion="h";
        private $imagen;
     //   private $codigo_anuncio1 = 0;
        private $codigo_usuario;
        private $email;
  //      private $anuncio_seleccionado;

        private $filtro_categoria="%";
       
        private $ofrezco1;
        private $descripcion1;
        private $imagen1;
        private $imagenes;

        private $codigo_anuncio2 = 0;
        private $ofrezco2;
        private $descripcion2;
        private $imagen2;

        private $codigo_anuncio3 = 0;
        private $ofrezco3;
        private $descripcion3;
        private $imagen3;

        private $codigo_anuncio4 = 0;
        private $ofrezco4;
        private $descripcion4;
        private $imagen4;
        
        private $codigo_anuncio5 = 0;
        private $ofrezco5;
        private $descripcion5;
        private $imagen5;

        private $codigo_anuncio6 = 0;
        private $ofrezco6;
        private $descripcion6;
        private $imagen6;

        private $codigo_anuncio7 = 0;
        private $ofrezco7;
        private $descripcion7;
        private $imagen7;

        private $codigo_anuncio8 = 0;
        private $ofrezco8;
        private $descripcion8;
        private $imagen8;

        private $codigo_anuncio9 = 0;
        private $ofrezco9;
        private $descripcion9;
        private $imagen9;


        public function Crear_Anuncio(){

            require("conexionPDO_modelo.php");

            // Recepcionamos los datos

            $ofrezco = htmlentities(addslashes($_POST["ofrezco"]));
            $descripcion = htmlentities(addslashes($_POST["descripcion"]));
            $valor =  htmlentities(addslashes($_POST["valor"]));
            $categoria = htmlentities(addslashes($_POST["seleccion"]));
        
            $directorio = "fotos/";
            $usuario = $_SESSION['usuario'];
            $archivo = $directorio . basename ($_FILES ['imagen']['name']);
            move_uploaded_file($_FILES["imagen"]["tmp_name"],$archivo);
        
            $consulta = "INSERT INTO Anuncios (Ofrezco, Descripcion, Valor, Categoría, Imagenes, Activo)
            VALUES (:ofrezco, :descripcion, :valor, :categoria, :archivo, 1)";
            $resultado=$conexion->prepare($consulta);
            $resultado->execute (array(":ofrezco"=>$ofrezco, ":descripcion"=>$descripcion, ":valor"=>$valor, 
            ":categoria"=>$categoria, ":archivo"=>$archivo));
        }
    
        public function Buscar_Anuncio(){

        require("conexionPDO_modelo.php");
        
        $directorio = "fotos/";
        $usuario = $_SESSION['usuario']; 

        $consulta = "SELECT NombreUsuario, Ofrezco, Descripcion, Valor, Categoría, Imagenes
                        FROM Anuncios WHERE NombreUsuario = ? AND Activo =1";

        $resultado = $conexion->prepare("$consulta");
        $resultado->execute(array($usuario));

            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            $this->nombre_usuario= $fila["NombreUsuario"];
            $this->ofrezco = $fila["Ofrezco"];
            $this->descripcion = $fila["Descripcion"];
            $this->valor = $fila["Valor"];
            $this->categoria["Categoria"];
           // $this->imagenes = $directorio . basename ($_FILES ['imagen']['name']);
            
            }
            public function get_Codigo_anuncio(){
            return $this->codigo_anuncio;

            }
            public function get_Nombre_usuario(){
            return $this->nombre_usuario;
            }

            public function get_Codigo_usuario(){
                return $this->codigo_usuario;
                
                }

                public function get_Email(){
                    return $this->email;
                    
                    }

            public function get_Ofrezco(){
                return $this->ofrezco;

            }

            public function get_Codigo_anuncio2(){
                return $this->codigo_anuncio2;
            }

            public function get_Ofrezco2(){
                return $this->ofrezco2;
            }

            public function get_Imagenes(){
                return $this->imagenes;
            }

            public function get_Ofrezco1(){
                return $this->ofrezco1;
            }
          
            public function get_Descripcion(){
                return $this->descripcion;
            }
            public function get_Descripcion1(){
                return $this->descripcion1;
            }

            public function get_Descripcion2(){
                return $this->descripcion2;
            }

            public function get_Imagen2(){
                return $this->imagen2;
            }
            public function get_Valor(){
                return $this->valor;
            }
            public function get_Categoria(){
                return $this->categoria;
            }

            public function get_Imagen(){
                return $this->imagen;
            }

            public function get_Imagen1(){
                return $this->imagen1;
            }

            public function get_Codigo_anuncio3(){
                return $this->codigo_anuncio3;
            }

            public function get_Ofrezco3(){
                return $this->ofrezco3;
            }
            public function get_Imagen3(){
                return $this->imagen3;
            }
            public function get_Descripcion3(){
                return $this->descripcion3;
            }

            public function get_Codigo_anuncio4(){
                return $this->codigo_anuncio4;
            }

            public function get_Ofrezco4(){
                return $this->ofrezco4;
            }
            public function get_Imagen4(){
                return $this->imagen4;
            }
            public function get_Descripcion4(){
                return $this->descripcion4;
            }

            public function get_Codigo_anuncio5(){
                return $this->codigo_anuncio5;
            }

            public function get_Ofrezco5(){
                return $this->ofrezco5;
            }
            public function get_Imagen5(){
                return $this->imagen5;
            }
            public function get_Descripcion5(){
                return $this->descripcion5;
            }

            public function get_Codigo_anuncio6(){
                return $this->codigo_anuncio6;
            }

            public function get_Ofrezco6(){
                return $this->ofrezco6;
            }
            public function get_Imagen6(){
                return $this->imagen6;
            }
            public function get_Descripcion6(){
                return $this->descripcion6;
            }
            public function get_Codigo_anuncio7(){
                return $this->codigo_anuncio5;
            }

            public function get_Ofrezco7(){
                return $this->ofrezco7;
            }
            public function get_Imagen7(){
                return $this->imagen7;
            }
            public function get_Descripcion7(){
                return $this->descripcion7;
            }
            public function get_Codigo_anuncio8(){
                return $this->codigo_anuncio8;
            }

            public function get_Ofrezco8(){
                return $this->ofrezco8;
            }
            public function get_Imagen8(){
                return $this->imagen8;
            }
            public function get_Descripcion8(){
                return $this->descripcion8;
            }
            public function get_Codigo_anuncio9(){
                return $this->codigo_anuncio9;
            }

            public function get_Ofrezco9(){
                return $this->ofrezco9;
            }
            public function get_Imagen9(){
                return $this->imagen9;
            }
            public function get_Descripcion9(){
                return $this->descripcion9;
            }

       
        public function Modificar_Anuncio(){
            require("conexionPDO_modelo.php");
        // session_start(); 

        // Recepcionamos los datos

            $usuario = $_POST["nombre_usuario"];
            $ofrezco = htmlentities(addslashes($_POST["ofrezco"]));
            $descripcion = htmlentities(addslashes($_POST["descripcion"]));
            $valor = $_POST["valor"];
            $categoria = $_POST["seleccion"];
            

            $directorio = "fotos/";
            $archivo = $directorio . basename ($_FILES ['imagen']['name']);
            move_uploaded_file($_FILES["imagen"]["tmp_name"],$archivo);

        $consulta = "UPDATE Anuncios Set  Ofrezco= :ofrezco, Descripcion= :descripcion, 
        Valor= :valor, Categoría= :categoria, Imagenes= :archivo
        WHERE NombreUsuario = :usuario AND Activo = 1"; 

        $resultado = $conexion->prepare($consulta);
        $resultado->execute (array( ":ofrezco"=>$ofrezco, ":descripcion"=>$descripcion, 
        "valor"=>$valor, ":categoria"=>$categoria, "archivo"=>$archivo, ":usuario"=>$usuario));

        }

        public function Borrar_Anuncio(){

            require("conexionPDO_modelo.php");
            $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
            $consulta = "UPDATE Anuncios Set  Activo =0 WHERE NombreUsuario =?"; 
            echo $usuario;
    
            $resultado = $conexion->prepare($consulta);
            $resultado->execute (array($usuario));
            //header ("location:../index.php");
            
        }

        public function Menu_Principal(){
            require("conexionPDO_modelo.php");

  //          $this->filtro_categoria = $_POST["filtro_categoria"];
            
            $sql_total = "SELECT CodigoAnuncio, Ofrezco, Descripcion, Imagenes 
            from Anuncios WHERE Categoría LIKE ?"; 
            
            $resultado = $conexion->prepare($sql_total);
            $resultado->execute(array($this->filtro_categoria));        
           
           while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)){

                $this->codigo_anuncio= $registro["CodigoAnuncio"];
                $this->ofrezco= $registro["Ofrezco"];
                $this->descripcion = $registro["Descripcion"];
               

                if ($this->codigo_anuncio1==0){
                    $this->codigo_anuncio1= $registro['CodigoAnuncio'];
                    $this->ofrezco1=$registro["Ofrezco"];
                    $this->descripcion1=$registro["Descripcion"];
                    $this->imagen1 = $registro["Imagenes"];
                    
                } else if($this->codigo_anuncio2==0){
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1= $registro['CodigoAnuncio'];
                    $this->ofrezco2= $this->ofrezco1;
                    $this->ofrezco1=$registro["Ofrezco"];
                    $this->imagen2 = $this->imagen1;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];
                    $this->imagen1 = $registro["Imagenes"]; 

                } else if($this->codigo_anuncio3==0){
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];
               
                } else if($this->codigo_anuncio4==0){
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];

                } else if($this->codigo_anuncio5==0){
                    $this->codigo_anuncio5 = $this->codigo_anuncio4;
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco5 = $this->ofrezco4;
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen5 = $this->imagen4;
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion5 = $this->descripcion4;
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];

                } else if($this->codigo_anuncio6==0){
                    $this->codigo_anuncio6 = $this->codigo_anuncio5;
                    $this->codigo_anuncio5 = $this->codigo_anuncio4;
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco6 = $this->ofrezco5;
                    $this->ofrezco5 = $this->ofrezco4;
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen6 = $this->imagen5;
                    $this->imagen5 = $this->imagen4;
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion6 = $this->descripcion5;
                    $this->descripcion5 = $this->descripcion4;
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];

                } else if($this->codigo_anuncio7==0){
                    $this->codigo_anuncio7 = $this->codigo_anuncio6;
                    $this->codigo_anuncio6 = $this->codigo_anuncio5;
                    $this->codigo_anuncio5 = $this->codigo_anuncio4;
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco7 = $this->ofrezco6;
                    $this->ofrezco6 = $this->ofrezco5;
                    $this->ofrezco5 = $this->ofrezco4;
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen7 = $this->imagen6;
                    $this->imagen6 = $this->imagen5;
                    $this->imagen5 = $this->imagen4;
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion7 = $this->descripcion6;
                    $this->descripcion6 = $this->descripcion5;
                    $this->descripcion5 = $this->descripcion4;
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];
                }   else if($this->codigo_anuncio8==0){
                    $this->codigo_anuncio8 = $this->codigo_anuncio7;
                    $this->codigo_anuncio7 = $this->codigo_anuncio6;
                    $this->codigo_anuncio6 = $this->codigo_anuncio5;
                    $this->codigo_anuncio5 = $this->codigo_anuncio4;
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco8 = $this->ofrezco7;
                    $this->ofrezco7 = $this->ofrezco6;
                    $this->ofrezco6 = $this->ofrezco5;
                    $this->ofrezco5 = $this->ofrezco4;
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen8 = $this->imagen7;
                    $this->imagen7 = $this->imagen6;
                    $this->imagen6 = $this->imagen5;
                    $this->imagen5 = $this->imagen4;
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion8 = $this->descripcion7;
                    $this->descripcion7 = $this->descripcion6;
                    $this->descripcion6 = $this->descripcion5;
                    $this->descripcion5 = $this->descripcion4;
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];
                }  else if($this->codigo_anuncio9==0){
                    $this->codigo_anuncio9 = $this->codigo_anuncio8;
                    $this->codigo_anuncio8 = $this->codigo_anuncio7;
                    $this->codigo_anuncio7 = $this->codigo_anuncio6;
                    $this->codigo_anuncio6 = $this->codigo_anuncio5;
                    $this->codigo_anuncio5 = $this->codigo_anuncio4;
                    $this->codigo_anuncio4 = $this->codigo_anuncio3;
                    $this->codigo_anuncio3 = $this->codigo_anuncio2;
                    $this->codigo_anuncio2 = $this->codigo_anuncio1;
                    $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                    $this->ofrezco9 = $this->ofrezco8;
                    $this->ofrezco8 = $this->ofrezco7;
                    $this->ofrezco7 = $this->ofrezco6;
                    $this->ofrezco6 = $this->ofrezco5;
                    $this->ofrezco5 = $this->ofrezco4;
                    $this->ofrezco4 = $this->ofrezco3;
                    $this->ofrezco3 = $this->ofrezco2;
                    $this->ofrezco2 = $this->ofrezco1;
                    $this->ofrezco1 = $registro["Ofrezco"];
                    $this->imagen9 = $this->imagen8;
                    $this->imagen8 = $this->imagen7;
                    $this->imagen7 = $this->imagen6;
                    $this->imagen6 = $this->imagen5;
                    $this->imagen5 = $this->imagen4;
                    $this->imagen4 = $this->imagen3;
                    $this->imagen3 = $this->imagen2;
                    $this->imagen2 = $this->imagen1;
                    $this->imagen1 = $registro["Imagenes"];
                    $this->descripcion9 = $this->descripcion8;
                    $this->descripcion8 = $this->descripcion7;
                    $this->descripcion7 = $this->descripcion6;
                    $this->descripcion6 = $this->descripcion5;
                    $this->descripcion5 = $this->descripcion4;
                    $this->descripcion4 = $this->descripcion3;
                    $this->descripcion3 = $this->descripcion2;
                    $this->descripcion2 = $this->descripcion1;
                    $this->descripcion1=$registro["Descripcion"];
                }  
                
               
             //  echo $this->ofrezco1 . "<br>" . "<br>";
              // echo $this->ofrezco2 . "<br>";
           }
            
        }
        
        public function Añadir_Filtros(){

            require("conexionPDO_modelo.php");

                      $this->filtro_categoria = $_POST["filtro_categoria"];
                      
                      $sql_total = "SELECT CodigoAnuncio, Ofrezco, Descripcion, Imagenes 
                      from Anuncios WHERE Categoría = ?"; 
                      
                      $resultado = $conexion->prepare($sql_total);
                      $resultado->execute(array($this->filtro_categoria));  
                      while ($registro = $resultado->fetch(PDO::FETCH_ASSOC)){

                        $this->codigo_anuncio= $registro["CodigoAnuncio"];
                        $this->ofrezco= $registro["Ofrezco"];
                        $this->descripcion = $registro["Descripcion"];
                       
        
                        if ($this->codigo_anuncio1==0){
                            $this->codigo_anuncio1= $registro["CodigoAnuncio"];
                            $this->ofrezco1=$registro["Ofrezco"];
                            $this->descripcion1=$registro["Descripcion"];
                            $this->imagen1 = $registro["Imagenes"];
                            
                        } else if($this->codigo_anuncio2==0){
                            $this->codigo_anuncio2= $this->codigo_anuncio1;
                            $this->codigo_anuncio1= $registro["CodigoAnuncio"];
                            $this->ofrezco2= $this->ofrezco1;
                            $this->ofrezco1=$registro["Ofrezco"];
                            $this->imagen2 = $this->imagen1;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
                            $this->imagen1 = $registro["Imagenes"]; 
        
                        } else if($this->codigo_anuncio3==0){
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
                       
                        } else if($this->codigo_anuncio4==0){
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
        
                        } else if($this->codigo_anuncio5==0){
                            $this->codigo_anuncio5 = $this->codigo_anuncio4;
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco5 = $this->ofrezco4;
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen5 = $this->imagen4;
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion5 = $this->descripcion4;
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
        
                        } else if($this->codigo_anuncio6==0){
                            $this->codigo_anuncio6 = $this->codigo_anuncio5;
                            $this->codigo_anuncio5 = $this->codigo_anuncio4;
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco6 = $this->ofrezco5;
                            $this->ofrezco5 = $this->ofrezco4;
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen6 = $this->imagen5;
                            $this->imagen5 = $this->imagen4;
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion6 = $this->descripcion5;
                            $this->descripcion5 = $this->descripcion4;
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
        
                        } else if($this->codigo_anuncio7==0){
                            $this->codigo_anuncio7 = $this->codigo_anuncio6;
                            $this->codigo_anuncio6 = $this->codigo_anuncio5;
                            $this->codigo_anuncio5 = $this->codigo_anuncio4;
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco7 = $this->ofrezco6;
                            $this->ofrezco6 = $this->ofrezco5;
                            $this->ofrezco5 = $this->ofrezco4;
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen7 = $this->imagen6;
                            $this->imagen6 = $this->imagen5;
                            $this->imagen5 = $this->imagen4;
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion7 = $this->descripcion6;
                            $this->descripcion6 = $this->descripcion5;
                            $this->descripcion5 = $this->descripcion4;
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
                        }   else if($this->codigo_anuncio8==0){
                            $this->codigo_anuncio8 = $this->codigo_anuncio7;
                            $this->codigo_anuncio7 = $this->codigo_anuncio6;
                            $this->codigo_anuncio6 = $this->codigo_anuncio5;
                            $this->codigo_anuncio5 = $this->codigo_anuncio4;
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco8 = $this->ofrezco7;
                            $this->ofrezco7 = $this->ofrezco6;
                            $this->ofrezco6 = $this->ofrezco5;
                            $this->ofrezco5 = $this->ofrezco4;
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen8 = $this->imagen7;
                            $this->imagen7 = $this->imagen6;
                            $this->imagen6 = $this->imagen5;
                            $this->imagen5 = $this->imagen4;
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion8 = $this->descripcion7;
                            $this->descripcion7 = $this->descripcion6;
                            $this->descripcion6 = $this->descripcion5;
                            $this->descripcion5 = $this->descripcion4;
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
                        }  else if($this->codigo_anuncio9==0){
                            $this->codigo_anuncio9 = $this->codigo_anuncio8;
                            $this->codigo_anuncio8 = $this->codigo_anuncio7;
                            $this->codigo_anuncio7 = $this->codigo_anuncio6;
                            $this->codigo_anuncio6 = $this->codigo_anuncio5;
                            $this->codigo_anuncio5 = $this->codigo_anuncio4;
                            $this->codigo_anuncio4 = $this->codigo_anuncio3;
                            $this->codigo_anuncio3 = $this->codigo_anuncio2;
                            $this->codigo_anuncio2 = $this->codigo_anuncio1;
                            $this->codigo_anuncio1 = $registro["CodigoAnuncio"];
                            $this->ofrezco9 = $this->ofrezco8;
                            $this->ofrezco8 = $this->ofrezco7;
                            $this->ofrezco7 = $this->ofrezco6;
                            $this->ofrezco6 = $this->ofrezco5;
                            $this->ofrezco5 = $this->ofrezco4;
                            $this->ofrezco4 = $this->ofrezco3;
                            $this->ofrezco3 = $this->ofrezco2;
                            $this->ofrezco2 = $this->ofrezco1;
                            $this->ofrezco1 = $registro["Ofrezco"];
                            $this->imagen9 = $this->imagen8;
                            $this->imagen8 = $this->imagen7;
                            $this->imagen7 = $this->imagen6;
                            $this->imagen6 = $this->imagen5;
                            $this->imagen5 = $this->imagen4;
                            $this->imagen4 = $this->imagen3;
                            $this->imagen3 = $this->imagen2;
                            $this->imagen2 = $this->imagen1;
                            $this->imagen1 = $registro["Imagenes"];
                            $this->descripcion9 = $this->descripcion8;
                            $this->descripcion8 = $this->descripcion7;
                            $this->descripcion7 = $this->descripcion6;
                            $this->descripcion6 = $this->descripcion5;
                            $this->descripcion5 = $this->descripcion4;
                            $this->descripcion4 = $this->descripcion3;
                            $this->descripcion3 = $this->descripcion2;
                            $this->descripcion2 = $this->descripcion1;
                            $this->descripcion1=$registro["Descripcion"];
                        }  
                        
                       
                     //  echo $this->ofrezco1 . "<br>" . "<br>";
                      // echo $this->ofrezco2 . "<br>";
                   }
                              

        }
        public function Ver_Anuncio($anuncio_pulsado){
            require("conexionPDO_modelo.php");
            if ($anuncio_pulsado == "anuncio1"){
              $this->codigo_anuncio=$_POST["codigo_anuncio1"];  
              }else if ($anuncio_pulsado == "anuncio2"){
                $this->codigo_anuncio=$_POST["codigo_anuncio2"];
                } else if ($anuncio_pulsado == "anuncio3"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio3"];
                } else if ($anuncio_pulsado == "anuncio4"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio4"];   
                }else if ($anuncio_pulsado == "anuncio5"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio5"];
                }else if ($anuncio_pulsado == "anuncio6"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio6"];
                }else if ($anuncio_pulsado == "anuncio7"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio7"];
                }else if ($anuncio_pulsado == "anuncio8"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio8"];
                }else if ($anuncio_pulsado == "anuncio9"){
                    $this->codigo_anuncio=$_POST["codigo_anuncio9"];
            }
            $directorio = "fotos/";
       //     $usuario = $_SESSION['usuario']; 

            $consulta = "SELECT Ofrezco, Descripcion, Valor, Imagenes, CodigoUsuario 
            FROM Anuncios WHERE CodigoAnuncio = ?";

            $resultado = $conexion->prepare("$consulta");
            $resultado->execute(array($this->codigo_anuncio));

            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

        //    $this->nombre_usuario= $fila["NombreUsuario"];
            $this->ofrezco = $fila["Ofrezco"];
            $this->descripcion = $fila["Descripcion"];
            $this->codigo_usuario = $fila["CodigoUsuario"];
            $this->valor = $fila["Valor"];
            $this->imagen = $fila["Imagenes"];
            $this->codigo_usuario = $fila ["CodigoUsuario"];

            $consulta = "SELECT Email
            FROM Usuarios WHERE CodigoUsuario = ?";

            $resultado = $conexion->prepare("$consulta");
            $resultado->execute(array($this->codigo_usuario));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->email = $fila ["Email"];

        /*    echo $codigo_anuncio . "<br>";
            echo $this->ofrezco . "<br>";
            echo $this->descripcion . "<br>";
            echo $this->valor = $fila["Valor"] . "<br>";
            echo $this->imagen = $fila["Imagenes"];
            */    
        }
    }
    










?>