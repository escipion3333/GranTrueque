<?php
    // Realizamos la conexión
    Class Anuncio{

        private $codigo_anuncio;
        private $nombre_usuario;
        private $ofrezco;
        private $descripción;
        private $valor;
        private $categoria;
        private $imagenes;

        public function Crear_Anuncio(){

            require("conexionPDO_modelo.php");

            // Recepcionamos los datos

            $ofrezco = htmlentities(addslashes($_POST["ofrezco"]));
            $descripcion = htmlentities(addslashes($_POST["descripcion"]));
            $valor =  htmlentities(addslashes($_POST["valor"]));
            $categoria = htmlentities(addslashes($_POST["seleccion"]));
        // $carpeta_destino = $_SERVER ['DOCUMENT_ROOT'].['imagenes'];
        
            $directorio = "fotos/";
            $archivo = $directorio . basename ($_FILES ['imagen']['name']);
            move_uploaded_file($_FILES["imagen"]["tmp_name"],$archivo);
        
            
            $consulta = "INSERT INTO Anuncios (Ofrezco, Descripcion, Valor, Categoría, Imagenes)
            VALUES (:ofrezco, :descripcion, :valor, :categoria, :archivo)";
            $resultado=$conexion->prepare($consulta);
            $resultado->execute (array(":ofrezco"=>$ofrezco, ":descripcion"=>$descripcion, ":valor"=>$valor, 
            ":categoria"=>$categoria, ":archivo"=>$archivo));
            //  header ("location:../index.php");
        }
    
        public function Buscar_Anuncio(){

        require("conexionPDO_modelo.php");
        
        $directorio = "fotos/";
        $usuario = $_SESSION['usuario']; 

        $consulta = "SELECT NombreUsuario, Ofrezco, Descripcion, Valor, Categoría, Imagenes
                        FROM Anuncios WHERE NombreUsuario = ? AND Activo =1";

        $resultado = $conexion->prepare("$consulta");
        $resultado->execute(array($usuario));

            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            $this->nombre_usuario= $fila["NombreUsuario"];
            $this->ofrezco = $fila["Ofrezco"];
            $this->descripcion = $fila["Descripcion"];
            $this->valor = $fila["Valor"];
            $this->categoria["Categoria"];
           // $this->imagenes = $directorio . basename ($_FILES ['imagen']['name']);
            
        }
            public function get_Codigo_anuncio(){
            return $this->codigo_anuncio;

        }
            public function get_Nombre_usuario(){
            return $this->nombre_usuario;

        }
            public function get_Ofrezco(){
                return $this->ofrezco;

            }

            public function get_Descripcion(){
                return $this->descripcion;
            }

            public function get_Valor(){
                return $this->valor;
            }
            public function get_Categoria(){
                return $this->categoria;
            }

            public function get_Imagenes(){
                return $this->imagenes;
            }

        
        public function Modificar_Anuncio(){
            require("conexionPDO_modelo.php");
        // session_start(); 

        // Recepcionamos los datos

            $usuario = $_POST["nombre_usuario"];
            $ofrezco = htmlentities(addslashes($_POST["ofrezco"]));
            $descripcion = htmlentities(addslashes($_POST["descripcion"]));
            $valor = $_POST["valor"];
            $categoria = $_POST["seleccion"];
            

            $directorio = "fotos/";
            $archivo = $directorio . basename ($_FILES ['imagen']['name']);
            move_uploaded_file($_FILES["imagen"]["tmp_name"],$archivo);

        $consulta = "UPDATE Anuncios Set  Ofrezco= :ofrezco, Descripcion= :descripcion, 
        Valor= :valor, Categoría= :categoria, Imagenes= :archivo
        WHERE NombreUsuario = :usuario AND Activo = 1"; 

        $resultado = $conexion->prepare($consulta);
        $resultado->execute (array( ":ofrezco"=>$ofrezco, ":descripcion"=>$descripcion, 
        "valor"=>$valor, ":categoria"=>$categoria, "archivo"=>$archivo, ":usuario"=>$usuario));

        }

        public function Borrar_Anuncio(){

            require("conexionPDO_modelo.php");
            $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
            $consulta = "UPDATE Anuncios Set  Activo =0 WHERE NombreUsuario =?"; 
            echo $usuario;
    
            $resultado = $conexion->prepare($consulta);
            $resultado->execute (array($usuario));
            //header ("location:../index.php");
            
        }

        public function Menu_Principal(){
            require("conexionPDO_modelo.php");

            // Rescatamos los anuncios de la BB.d-md-block

            $consulta = "SELECT Ofrezco, CodigoAnuncio, Descripcion, Imagenes FROM Anuncios 
            WHERE NombreUsuario = 'Juan'";
                 
            $resultado = $conexion->prepare($consulta);
            $resultado->execute (array());
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            $this->codigo_anuncio= $fila["CodigoAnuncio"];
            $this->ofrezco= $fila["Ofrezco"];
            $this->descripcion = $fila["Descripcion"];
            $this->imagenes = $fila["Imagenes"];

        }
            
    }
    
?>