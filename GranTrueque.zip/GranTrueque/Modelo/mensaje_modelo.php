<?php
    // Realizamos la conexión
    Class Mensaje{

        private $codigo_mensaje;
        private $descripcion_mensaje_anunciante; 
        private $codigo_usuario_anunciante;
        private $nombre_usuario_anunciante;
        private $codigo_anuncio_anunciante;
        private $nombre_usuario_origen;
        private $valor_anunciante;
        private $codigo_usuario_origen;
        private $codigo_anuncio_origen;
        private $codigo_postal;
        private $ofrezco;     
        private $tipo_mensaje;
        private $imagenes;
        private $valor;
        private $email_origen;
        private $estado;

        

        function Mensaje (){            // Constructor de la clase

            $this->descripcion_mensaje = "Ha recibido una solicitud de intercambio en Modo seguro. 
             Si lo desea puede aceptar o rechazar esta petición. El producto a intercambiar es;";
            $this->tipo_mensaje=1; 
            $this->estado = "Pendiente";

        }
             public function Nuevo_Mensaje(){
        
                if (isset ($_SESSION["usuario"])){
                    $this->usuario_solicitante = $_SESSION["usuario"];
                }
                
                require("conexionPDO_modelo.php");

         // Buscamos todos los anuncios del usuario logado

         $consulta = "SELECT CodigoAnuncio, Ofrezco, Valor, Imagenes, CodigoPostal, CodigoUsuario
         FROM Anuncios WHERE NombreUsuario = ? AND Activo=1";  

        $resultado = $conexion->prepare("$consulta");
        $resultado->execute(array($this->usuario_solicitante));
        $fila = $resultado->fetch(PDO::FETCH_ASSOC);

        $this->codigo_anuncio_origen = $fila["CodigoAnuncio"];
        $this->ofrezco = $fila["Ofrezco"];
        $this->valor = $fila["Valor"];
        $this->codigo_postal = $fila["CodigoPostal"];
        $this->imagenes = $fila["Imagenes"];
        $this->codigo_usuario_origen = $fila["CodigoUsuario"];
        $this->codigo_usuario_anunciante = $_POST ["codigo_anunciante"];
        $this->codigo_anuncio_anunciante = $_POST["codigo_anuncio_anunciante"]; 
        $this->descripcion_mensaje_anunciante = $_POST["ofrezco"];

        $consulta2 = "SELECT CodigoAnuncio, Valor
        FROM Anuncios WHERE CodigoAnuncio = ? AND Activo=1";
        $resultado = $conexion->prepare("$consulta2");
        $resultado->execute(array($this->codigo_anuncio_anunciante));
        $fila = $resultado->fetch(PDO::FETCH_ASSOC);
        $this->valor_anunciante = $fila["Valor"];

        $consulta3 = "INSERT INTO Mensajes (DescripcionMensajeAnunciante, CodigoAnuncioAnunciante,ValorAnunciante,
        CodigoUsuarioOrigen, CodigoAnuncioOrigen, CodigoPostalOrigen, OfrezcoOrigen, ValorOrigen, ImagenesOrigen,
        TipoMensaje, CodigoUsuarioAnunciante, Estado)
        VALUES (:descripcion_mensaje_anunciante, :codigo_anuncio_anunciante, :valor_anunciante,
        :codigo_usuario_origen, :codigo_anuncio_origen, :codigo_postal_origen, :ofrezco_origen, :valor_origen, :imagenes_origen, 
        :tipo_mensaje, :codigo_usuario_anunciante, :estado)";

        $resultado = $conexion->prepare("$consulta3");   
        $resultado->execute (array("descripcion_mensaje_anunciante"=>$this->descripcion_mensaje_anunciante, 
        ":codigo_anuncio_anunciante"=>$this->codigo_anuncio_anunciante,
        ":valor_anunciante"=>$this->valor_anunciante, 
        ":codigo_usuario_origen"=>$this->codigo_usuario_origen,
        ":codigo_anuncio_origen"=>$this->codigo_anuncio_origen,
        ":codigo_postal_origen"=>$this->codigo_postal,
        ":ofrezco_origen"=>$this->ofrezco,
        ":valor_origen"=>$this->valor,
        ":imagenes_origen"=>$this->imagenes,
        ":tipo_mensaje"=>$this->tipo_mensaje,
        ":codigo_usuario_anunciante"=>$this->codigo_usuario_anunciante,
        ":estado"=>$this->estado
        )); 

        }

    public function Ver_Propuestas_Aceptadas(){

        require("conexionPDO_modelo.php");

        if (isset ($_SESSION["usuario"])){
            $this->nombre_usuario_origen = $_SESSION["usuario"];
        }
        
        $consulta4 = "SELECT CodigoUsuario FROM Usuarios WHERE NombreUsuario=?";

        $this->estado = "Aceptado";
        $resultado = $conexion->prepare($consulta4);
        $resultado->execute(array($this->nombre_usuario_origen));
        $fila = $resultado->fetch(PDO::FETCH_ASSOC);
        $this->codigo_usuario_origen = $fila ["CodigoUsuario"];

        $consulta = "SELECT CodigoMensaje, OfrezcoOrigen, ValorOrigen, DescripcionMensajeAnunciante, ValorAnunciante
        FROM Mensajes WHERE CodigoUsuarioOrigen = :codigo_usuario_origen AND Estado = :estado";

        $resultado = $conexion->prepare("$consulta");
        $resultado->execute(array(":codigo_usuario_origen"=>$this->codigo_usuario_origen, 
        ":estado"=>$this->estado));
        $fila = $resultado->fetch(PDO::FETCH_ASSOC);

        $this->codigo_mensaje = $fila["CodigoMensaje"];
        $this->ofrezco = $fila ["OfrezcoOrigen"];
        $this->valor = $fila ["ValorOrigen"];
        $this->descripcion_mensaje_anunciante = $fila["DescripcionMensajeAnunciante"];
        $this->valor_anunciante = $fila ["ValorAnunciante"];

        }

        public function Aceptar_Propuesta(){
            if (isset ($_SESSION["usuario"])){
                $this->nombre_usuario_anunciante = $_SESSION["usuario"];
                require("conexionPDO_modelo.php");
                $this->codigo_mensaje = $_POST["codigo_mensaje"];

                $consulta6 = "UPDATE Mensajes SET Estado = 'Aceptado' 
                WHERE CodigoMensaje = $this->codigo_mensaje";
        
                $resultado = $conexion->prepare($consulta6);
                $resultado->execute(array());

            //    $this->estado = "Rechazado";

            }
        }

        public function Mostrar_Propuesta(){

            if (isset ($_SESSION["usuario"])){
                $this->nombre_usuario_anunciante = $_SESSION["usuario"];
            }
            
            require("conexionPDO_modelo.php");

            $consulta4 = "SELECT CodigoUsuario, Email FROM Usuarios WHERE NombreUsuario=?";
    
            $resultado = $conexion->prepare($consulta4);
            $resultado->execute(array($this->nombre_usuario_anunciante));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->codigo_usuario_anunciante = $fila ["CodigoUsuario"];
            $this->email_origen = $fila ["Email"];
            
            $consulta5 = "SELECT CodigoMensaje, CodigoUsuarioOrigen, CodigoAnuncioOrigen, OfrezcoOrigen, 
            ValorOrigen, ImagenesOrigen FROM Mensajes WHERE CodigoUsuarioAnunciante =?";
            
            $resultado = $conexion->prepare($consulta5);
            $resultado->execute(array($this->codigo_usuario_anunciante));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->codigo_mensaje = $fila ["CodigoMensaje"];
            $this->codigo_usuario_origen = $fila ["CodigoUsuarioOrigen"];
            $this->codigo_anuncio_origen = $fila ["CodigoAnuncioOrigen"];
            $this->ofrezco = $fila ["OfrezcoOrigen"];
            $this->valor = $fila ["ValorOrigen"];
            $this->imagenes = $fila ["ImagenesOrigen"];
    
        }    

        public function Rechazar_Mensaje(){
            if (isset ($_SESSION["usuario"])){
                $this->nombre_usuario_anunciante = $_SESSION["usuario"];
                require("conexionPDO_modelo.php");
                $this->codigo_mensaje = $_POST["codigo_mensaje"];

                $consulta6 = "UPDATE Mensajes SET Estado = 'Rechazado' 
                WHERE CodigoMensaje = $this->codigo_mensaje";
        
                $resultado = $conexion->prepare($consulta6);
                $resultado->execute(array());

                $this->estado = "Rechazado";

            }
            
            require("conexionPDO_modelo.php");
        }

        public function Listar_Mensajes(){

            if (isset ($_SESSION["usuario"])){
                $this->nombre_usuario_anunciante = $_SESSION["usuario"];
            }

            require("conexionPDO_modelo.php");

            ///////////////   Mensajes recibidos  ///////////////////////

            $consulta7 = "SELECT CodigoUsuario FROM Usuarios WHERE NombreUsuario=?";
    
            $resultado = $conexion->prepare($consulta7);
            $resultado->execute(array($this->nombre_usuario_anunciante));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->codigo_usuario_anunciante = $fila ["CodigoUsuario"];

            $consulta8 = "SELECT CodigoUsuarioOrigen, OfrezcoOrigen, CodigoPostalOrigen, 
            ValorOrigen, DescripcionMensajeAnunciante, ValorAnunciante, Estado
            FROM Mensajes WHERE CodigoUsuarioAnunciante=?";

            $resultado = $conexion->prepare($consulta8);
            $resultado->execute(array($this->codigo_usuario_anunciante));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            while ($registro= $resultado->fetch(PDO::FETCH_ASSOC)){
        echo    $this->codigo_usuario_anunciante . " ";
        echo    $this->codigo_usuario_origen = $fila ["CodigoUsuarioOrigen"] . " ";
        echo    $this->ofrezco_origen = $fila ["OfrezcoOrigen"] . " ";
        echo    $this->codigo_postal_origen = $fila ["CodigoPostalOrigen"] . " ";
        echo    $this->valor_origen = $fila ["ValorOrigen"] . " ";
        echo    $this->descripcion_mensaje_anunciante = $fila ["DescripcionMensajeAnunciante"] . " ";
        echo    $this->valor_anunciante = $fila ["ValorAnunciante"] . " ";    
        echo    $this->estado = $fila ["Estado"] . " " ;
        echo    "<br>";
            }   
        //////////////    Mensajes emitidos    ////////////////////////
            $consulta9 = "SELECT CodigoUsuario FROM Usuarios WHERE NombreUsuario=?";
        
            $resultado = $conexion->prepare($consulta9);
            $resultado->execute(array($this->nombre_usuario_anunciante));
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->codigo_usuario_origen = $fila ["CodigoUsuario"];

            $consulta10 = "SELECT CodigoUsuarioOrigen, OfrezcoOrigen, CodigoPostalOrigen, 
            ValorOrigen, DescripcionMensajeAnunciante, ValorAnunciante, Estado
            FROM Mensajes WHERE CodigoUsuarioOrigen=?";

            $resultado = $conexion->prepare($consulta10);
            $resultado->execute(array($this->codigo_usuario_origen));

            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            while ($registro= $resultado->fetch(PDO::FETCH_ASSOC)){
        echo    $this->codigo_usuario_anunciante . " ";
        echo    $this->codigo_usuario_origen = $fila ["CodigoUsuarioOrigen"] . " ";
        echo    $this->ofrezco_origen = $fila ["OfrezcoOrigen"] . " ";
        echo    $this->codigo_postal_origen = $fila ["CodigoPostalOrigen"] . " ";
        echo    $this->valor_origen = $fila ["ValorOrigen"] . " ";
        echo    $this->descripcion_mensaje_anunciante = $fila ["DescripcionMensajeAnunciante"] . " ";
        echo    $this->valor_anunciante = $fila ["ValorAnunciante"] . " ";    
        echo    $this->estado = $fila ["Estado"] . " " ;
        echo    "<br>";
            }      

        }

        public function get_Codigo_Mensaje(){
            return $this->codigo_mensaje;
        }
        public function get_Descripcion_Mensaje_Anunciante(){
            return $this->descripcion_mensaje_anunciante;
        }

        public function get_Codigo_Usuario_Anunciante(){
            return $this->codigo_usuario_anunciante;
        }

        public function get_Codigo_Anuncio_Anunciante(){
            return $this->codigo_anuncio_anunciante;
        }

        public function get_Valor_Anunciante(){
            return $this->valor_anunciante;
        }

        public function get_Codigo_Usuario_Origen(){
            return $this->codigo_usuario_origen;
        }

        public function get_Codigo_Anuncio_Origen(){
            return $this->codigo_anuncio_origen;
        }

        public function get_Valor_Origen(){
            return $this->valor;
        }

        public function get_Codigo_Postal(){
            return $this->codigo_postal;
        }
        
        public function get_Ofrezco_Origen(){
            return $this->ofrezco;
        }

        public function get_Tipo_Mensaje(){
            return $this->tipo_mensaje;
        }

        public function get_Imagenes_Origen(){
           return $this->imagenes;
        }

        public function get_Email_Origen(){
            return $this->email_origen;
         }

         public function get_Estado(){
            return $this->estado;
         }
        
        
        
    } 
    
?>