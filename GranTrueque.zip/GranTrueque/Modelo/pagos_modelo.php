<?php
    // Realizamos la conexión
    Class Pagos{

        private $usuario_origen;
        private $valor_origen;
        private $usuario_anunciante;
        private $estado_origen="Pagado";
        private $valor_anunciante;
        private $codigo_anuncio;
        private $codigo_usuario;
        private $estado_anunciante="Pagado";
     

        public function Pago_Anunciante(){
        
            if (isset ($_SESSION["usuario"])){
                $this->usuario_anunciante = $_SESSION["usuario"];
            }
                
            require("conexionPDO_modelo.php");

            $this->codigo_anuncio = $_POST["codigo_mensaje"];

            $consulta1 = "SELECT ValorAnunciante FROM Mensajes 
            WHERE CodigoMensaje = ?";
          
            $resultado = $conexion->prepare($consulta1);
            $resultado->execute (array($this->codigo_anuncio)); 
            $fila = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->valor_anunciante = $fila["ValorAnunciante"];

            // Insertamos el pago del anunciante //

            $consulta3 = "INSERT INTO Pagos (CodigoAnuncio, UsuarioAnunciante, ValorAnunciante, EstadoAnunciante)
            VALUES (:codigo_anuncio, :usuario_anunciante, :valor_anunciante, :estado_anunciante)";
  
            $resultado = $conexion->prepare($consulta3);   
            $resultado->execute (array(":codigo_anuncio"=>$this->codigo_anuncio, 
            ":usuario_anunciante"=>$this->usuario_anunciante,
            ":valor_anunciante"=>$this->valor_anunciante,
            ":estado_anunciante"=>$this->estado_anunciante
            )); 
        
        }
        
            public function Pagar_Origen(){

                if (isset ($_SESSION["usuario"])){
                    $this->usuario_origen = $_SESSION["usuario"];
                }
                require("conexionPDO_modelo.php");

                // Obtenemos el código del usuario origen //

                $consulta = "SELECT CodigoUsuario FROM Usuarios WHERE NombreUsuario = ?";

                $resultado = $conexion->prepare($consulta);   
                $resultado->execute (array($this->usuario_origen));
                $fila = $resultado->fetch(PDO::FETCH_ASSOC);
                $this->codigo_usuario = $fila["CodigoUsuario"];

                $consulta = "SELECT ValorOrigen, CodigoMensaje FROM Mensajes 
                WHERE CodigoUsuarioOrigen = ?";
          
                $resultado = $conexion->prepare($consulta);
                $resultado->execute (array($this->codigo_usuario)); 
                $fila = $resultado->fetch(PDO::FETCH_ASSOC);
                $this->valor_origen = $fila["ValorOrigen"];
                $this->codigo_anuncio = $fila ["CodigoMensaje"]; 
                
                $consulta8 = "UPDATE Pagos SET UsuarioOrigen = :usuario_origen,
                ValorOrigen = :valor_origen, EstadoOrigen = :estado_origen";
                $resultado = $conexion->prepare($consulta8);
                $resultado->execute (array(":usuario_origen"=>$this->usuario_origen,
                "valor_origen" => $this->valor_origen,
                "estado_origen" => $this->estado_origen)); 
                
            }
    
    } 
    
?>