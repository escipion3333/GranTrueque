<?php
    // Realizamos la conexión
    Class Trueque{

        private $usuario;
        private $codigo_anuncio;
        private $ofrezco;
        private $valor;


        public function Buscar_Anuncios(){
            session_start();
            if (isset ($_SESSION["usuario"])){
                $this->usuario = $_SESSION["usuario"];
            }
            
            require("conexionPDO_modelo.php");

         // Buscamos todos los anuncios del usuario logado


            $usuario = $_SESSION['usuario']; 
            $consulta = "SELECT CodigoAnuncio, Ofrezco, Valor
                        FROM Anuncios WHERE NombreUsuario = ? AND Activo=1";   

            $resultado = $conexion->prepare("$consulta");
            $resultado->execute(array($this->usuario));

            $fila = $resultado->fetch(PDO::FETCH_ASSOC);

            $this->codigo_anuncio = $fila["CodigoAnuncio"];
            $this->ofrezco = $fila["Ofrezco"];
            $this->valor = $fila["Valor"];

           // echo $this->codigo_anuncio;
        }
    ///////////////////////////////////////////////////////
/*
    $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
    $contra = htmlentities(addslashes($_POST["clave"]));        
    $consulta = "SELECT * FROM Usuarios WHERE NombreUsuario = :user";
    $resultado = $conexion->prepare($consulta);        
    $resultado->execute(array("user"=>$usuario));
    $fila = $resultado->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario== $fila["NombreUsuario"] && password_verify($contra,$fila["Clave"]) 
    && $fila["Activo"]==1){

        // Iniciamos sesión
        echo "Estamos dentro del bucle";
        session_start();
        $_SESSION['usuario'] = $_POST['nombre_usuario'];
    
        header ("location:../index.php");


    } else {

       // Si no se encuentra al usuario
       header ("location:../Controlador/login_controlador.php");
    }

        }

    public function Crear_Usuario(){

        require("conexionPDO_modelo.php");

        // Recepcionamos los datos

        $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
        $clave = htmlentities(addslashes($_POST["clave"]));
        $clave_cifrada = password_hash($clave,PASSWORD_DEFAULT);
        $confirmar = htmlentities(addslashes($_POST["confirmar"]));
        $email = htmlentities(addslashes($_POST["email"]));
        $codigo_postal = htmlentities(addslashes($_POST["codigo_postal"]));
        $localidad = htmlentities(addslashes($_POST["localidad"]));
        $provincia = htmlentities(addslashes($_POST["provincia"]));
        $tipousuario = "Cliente";
        $activo = 1;

        // Comprobamos que la contraseña y la confirmación son iguales

        if ($clave!=$confirmar){
            echo '<script language="javascript">alert("La contraseña y la verificación no coincide");</script>';
        }else {
                $consulta = "INSERT INTO Usuarios (NombreUsuario, Clave, Email, CodigoPostal, Localidad, Provincia, TipoUsuario, Activo)
                VALUES (:usuario, :clave_cifrada, :email, :codigo_postal,:localidad,:provincia,:tipousuario, :activo)";
                $resultado=$conexion->prepare($consulta);
                $resultado->execute (array(":usuario"=>$usuario, ":clave_cifrada" =>$clave_cifrada,
                ":email"=>$email,":codigo_postal"=>$codigo_postal,":localidad"=>$localidad,
                ":provincia"=>$provincia, ":tipousuario"=>$tipousuario, ":activo"=>$activo));
                header ("location:../index.php");
         }

    }
  
    public function Buscar_Usuario(){

       require("conexionPDO_modelo.php");

       $usuario = $_SESSION['usuario']; 
       $consulta = "SELECT NombreUsuario, Clave, Email, CodigoPostal, Localidad, Provincia, TipoUsuario
                    FROM Usuarios WHERE NombreUsuario = ?";   

       $resultado = $conexion->prepare("$consulta");
       $resultado->execute(array($usuario));

        $fila = $resultado->fetch(PDO::FETCH_ASSOC);

        $this->usuario = $fila["NombreUsuario"];
        $this->clave = $fila["Clave"];
        $this->email = $fila["Email"];
        $this->CP=$fila["CodigoPostal"];
        $this->localidad = $fila["Localidad"];
        $this->provincia = $fila["Provincia"];
        
    } */

        public function get_Codigo_Anuncio(){
            return $this->codigo_anuncio;

        }

        public function get_Ofrezco(){
            return $this->ofrezco;
        }

        public function get_Valor(){
            return $this->valor;
        } 
        /*
        public function get_Codigo_Postal(){
            return $this->CP;
        }
        public function get_Localidad(){
            return $this->localidad;
        }
        public function get_Provincia(){
            return $this->provincia;
        }
    
    public function Modificar_Usuario(){
        require("conexionPDO_modelo.php");

       // Recepcionamos los datos

        $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
        $clave = htmlentities(addslashes($_POST["clave"]));
        $clave_cifrada = password_hash($clave,PASSWORD_DEFAULT);
       // $confirmar = htmlentities(addslashes($_POST["confirmar"]));
        $email = htmlentities(addslashes($_POST["email"]));
        $codigo_postal = htmlentities(addslashes($_POST["codigo_postal"]));
        $localidad = htmlentities(addslashes($_POST["localidad"]));
        $provincia = htmlentities(addslashes($_POST["provincia"]));
       // $tipousuario = "Cliente"; 

       $consulta = "UPDATE Usuarios Set  Email= :email, CodigoPostal= :codigo_postal, Localidad= :localidad, Provincia= :provincia
       WHERE NombreUsuario = :nombre_usuario AND Clave = :clave"; 

       $resultado = $conexion->prepare($consulta);
       $resultado->execute (array( ":email"=>$email, "codigo_postal"=>$codigo_postal, ":localidad"=>$localidad,
       ":provincia"=>$provincia,":nombre_usuario"=>$usuario, ":clave"=>$clave));
       header ("location:../index.php");
    }

    public function Baja_Usuario(){

        require("conexionPDO_modelo.php");
        $usuario = htmlentities(addslashes($_POST["nombre_usuario"]));
        $consulta = "UPDATE Usuarios Set  Activo =0 WHERE NombreUsuario = :usuario"; 
 
        $resultado = $conexion->prepare($consulta);
        $resultado->execute (array(":usuario"=>$usuario));
        header ("location:../index.php");
        
    }

    public function Cerrar_Sesion(){

        session_destroy();
        //header ("location:../index.php");

     } */ 
        
    } 
    
?>