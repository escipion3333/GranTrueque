<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
</head>
<body>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Cambiar por</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo deberás elegir un de tus anuncios 
                publicados por el que deseas cambiar el producto elegido</p>
               
                
                <form action = "principal_controler.php" method="POST">

                <section>              
                    <div>
                        <div class="col-md-8">
                            <?php
                            echo "<br>";
                            echo '<input type="hidden" name="codigo_anuncio_cambio" value="' . $codigo_anuncio.'"  readonly id="ofrezco" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            
                            echo '<input type="text" name="ofrezco" value="' . $ofrezco. '" readonly id="valor" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="valor" value="' . $valor.' € "  readonly id="email" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    </section>
                
                    <div class="row">
                        <div class="col">
                        <button type="submit" name="siguiente" class="btn btn-info">Siguiente</button>
                        <button type="submit" name="anterior" class="btn btn-info">Anterior</button>
                        <button type="submit" name="cambiar" class="btn btn-info">Cambiar</button>    
                        <button type="submit" name="menu_principal_cambio" class="btn btn-info">Menú Principal</button>
                    </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>