<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categorías</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/usuarios.css">
</head>
<body>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Gestión Categorías</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo pdrás crear, modificar y eliminar las categorías de productos</p>
                <p class="text-danger small pt-0 mt-0">Todos los campos son obligatorios</p>
                <form>
                    <div class="row form-group">
                        <label for="codigo_categoria" class="col-form-label col-md-4">Código categoría:</label>
                        <div class="col-md-8">
                             <input type="int" name="codigo_categoria" value="" id="codigo_categoria" class="form-control"> 
                        </div>              
                    </div>

                    <div class="row form-group">
                        <label for="descripcion_categoria" class="col-form-label col-md-4">Descripción</label>
                        <div class="col-md-8">
                             <input type="text" name="text" value="" id="text" class="form-control"> 
                        </div>              
                    </div>

                    <br> <br>

                    <div class="row">
                        <div class="col-md-4 form-group">
                        <button type="submit" name="enviar" class="btn btn-info">Enviar</button>
                        </div>

                        <div class="col-md-4">
                        <button type="submit" name="modificar" class="btn btn-info">Modificar</button>
                        </div>

                        <div class="col-md-4">
                        <button type="submit" name="eliminar" class="btn btn-info">Eliminar</button>
                        </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>