<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
</head>
<body>

    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Propuesta intercambio aceptada</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">Tu propuesta de intercambio ha sido aceptada. Para finalizar 
                el intercambio debes de realizar un pago por el importe del producto que publicaste. 
                contemplado en el campo "Valor de tu propuesta".</p>
                
                <form action = "mensajes_aceptados_controlador.php" method="POST">
                    <?php
                        echo '<input type="hidden" name="codigo" value="' . $codigo_mensaje . '" id="ofrezco_origen" class="form-control" readonly>'; 
                    ?>

                    <div class="row form-group">
                        <?php
                            echo '<label for="tu_producto" class="col-form-label col-md-4">Tu producto</label>
                            <div class="col-md-8">';
                            echo '<input type="text" name="ofrezco_origen" value="' . $ofrezco_origen . '" id="ofrezco_origen" class="form-control" readonly>'; 
                        ?>
                            </div>              
                    </div>

                    <div class="row form-group">
                        <?php
                            echo '<label for="clave" class="col-form-label col-md-4">Valor de tu propuesta</label>
                        <div class="col-md-8">';
                            echo '<input type="text" name="valor_origen" value="' . $valor_origen . '" id="valor_origen" readonly class="form-control">'; 
                        ?>
                             </div>              
                    </div>

                    <div class="row form-group">
                        <?php
                            echo '<label for="clave" class="col-form-label col-md-4">Cambiar por</label>
                            <div class="col-md-8">';
                            echo '<input type="text" name="descripcion_anunciante" value="' .  $descripcion_mensaje_anunciante . '" id="descripcion_anunciante" readonly class="form-control">';
                          
                        ?>
                            </div>              
                    </div>

                    <div class="row form-group">
                        <?php
                            echo '<label for="clave" class="col-form-label col-md-4">Valorado en</label>
                            <div class="col-md-8">';
                            echo '<input type="text" name="valorado_en" value="' .  $valor_anunciante . '" id="valorado_en" readonly class="form-control">';
                        ?>     
                        </div>              
                    </div>
                
                    <div class="row">
                        <div class="col">
                        <button type="submit" name="pagar" class="btn btn-info">Realizar Pago</button>
                        <button type="submit" name="menu_principal_aceptados" class="btn btn-info">Menú principal</button>
                        </div>
                    </div>

                    
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>