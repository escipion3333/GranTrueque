<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
</head>
<body>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Gestion Usuarios</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo podrás modificar y los datos de 
                tu cuenta de usuarios excepto el nombre y la contraseña. Para ello deberás
                de ponerte en contacto con la plataforma. También podrás darte de baja si lo deseas</p>
                <p class="text-danger small pt-0 mt-0">Todos los campos son obligatorios</p>
                <form action = "mi_cuenta_controlador.php" method="POST">
                                
                <div class="row form-group">  
                    <?php              
                        echo '<label for="nombre_usuario" class="col-form-label col-md-4">Nombre Usuario:</label>
                        <div class="col-md-8">';
                        echo  " <input type= 'text' name= 'nombre_usuario' value= '" . $usuario . "' readonly id='nombre_usuario' readonly  
                        class='form-control'>";
                    ?>  
                        </div>                                    
                    </div>
                    
                <div class="row form-group">                  
                    <?php                    
                        echo '<label for="clave" class="col-form-label col-md-4">Contraseña</label>
                        <div class="col-md-8">';
                        echo '<input type="password" name="clave" value= "' . $clave . '" id="clave" readonly class="form-control"> ';
                    ?>
                    </div>              
                </div>

                    <div class="row form-group">
                        <?php
                            echo '<label for="email" class="col-form-label col-md-4">Email</label>
                            <div class="col-md-8">';
                            echo  '<input type="email" name="email" value= "' . $email . '" id="email" class="form-control">'; 
                        ?>    
                            </div>              
                </div>

                    <div class="row form-group">

                    <?php
                        echo '<label for="codigo_postal" class="col-form-label col-md-4">Código Postal</label>
                        <div class="col-md-8">';
                        echo  '<input type="int" name="codigo_postal" value= "' . $codigo_postal . '" id="codigo_postal" class="form-control">'; 
                    ?>    
                        </div>              
                    </div>

                    <div class="row form-group">
                        <?php    
                            echo '<label for="localidad" class="col-form-label col-md-4">Localidad</label>
                            <div class="col-md-8">';
                            echo '<input type="text" name="localidad" value="' .$localidad . '" id="localidad" class="form-control">'; 
                        ?>    
                            </div>              
                    </div>

                    <div class="row form-group">
                        <?php
                            echo '<label for="provincia" class="col-form-label col-md-4">Provincia</label>
                            <div class="col-md-8">';
                            echo '<input type="text" name="provincia" value="' . $provincia . '" id="provincia" class="form-control">'; 
                        ?>    
                        </div>              
                    </div>

                    <div class="row">
                        <div class="col">
                        <button type="submit" name="modificar" class="btn btn-info">Modificar</button>
                        <button type="submit" name="baja" class="btn btn-info">Dar de baja</button>

                        </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>