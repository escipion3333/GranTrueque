<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
</head>
<body>
    <?php
    /////////// Comprobamos si el usuario ha abierto sesión /////////
   // session_start();

    if (!isset ($_SESSION["usuario"])){
       header("Location:../index.php");
    }
    ?>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Listado de mensajes</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo podrás ver una lista con todos tus 
                mensajes.
                </p>
                <br>
                <form action = "../Controlador/mis_mensajes_controlador.php" method="POST">
                  <section>
                
                    <div>
                        <div class="col-md-8">
                            <?php
                            echo "Mensajes recibidos";  
                            ?>                        
                        </div>            
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="hidden" name="codigo_usuario_origen" value="' . $codigo_usuario_origen.'"  readonly id="codigo_usuario_origen" class="form-control">';  
                            ?>                        
                         </div>              
                    </div>
                    
                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="hidden" name="codigo_anuncio_origen" value="' . $codigo_anuncio_origen.'"  readonly id="codigo_anuncio_origen" class="form-control">';  
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="ofrezco_origen" value="' . $ofrezco_origen.'"  readonly id="ofrezco_origen" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="valor_origen" value="' . $valor_origen. ' € " readonly id="valor_origen" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="email_origen" value="' . $email_origen.'"  readonly id="email" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <?php
                    echo '<a href="#" class="image featured"><img src="' . $ruta_origen . '" name="ruta_origen" width="250" height="350" alt="" /></a>';
                    
                    ?>
                    </section>
                    <div class="row">
                        <div class="col">
                            <button type="submit" name="pago" class="btn btn-info">Realizar pago</button>
                            <button type="submit" name="rechazar" class="btn btn-info">Rechazar trueque</button>
                            <button type="submit" name="menu_principal2" class="btn btn-info">Menú principal</button>
                        </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>