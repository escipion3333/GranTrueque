<!DOCTYPE HTML>
<!--
	Strongly Typed by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Gran Trueque Main</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />		
	</head>
	<form action = "Controlador/principal_controler.php" method="POST">
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<section id="header">
					<div class="container">

						<!-- Logo -->
							<h1 id="logo"><a href="index.html">Gran Trueque</a></h1>

						<!-- Nav -->
							<nav id="nav">
								<ul>
	
									<li>
										<a href="#" class="icon fa-chart-bar"><span>Entrar en la plataforma</span></a>
										<ul>
											<li><a href="Controlador/login_controlador.php">Login</a></li>
											<li><a href="Controlador/crear_usuario_controlador.php">Crear usuario</a></li>
											<li><a href="Controlador/mi_cuenta_controlador.php">Mi cuenta</a></li>
											
										</ul>
									</li>
									
									</li>
									
									<!-- <li><a class="icon solid fa-sitemap" href="Controlador/anuncios_controlador.php"><span>Mis anuncios</span></a></li> -->
									<li>
										<a href="#" class="icon fa-chart-bar"><span>Anuncios</span></a>
										<ul>											
											<li><a href="Controlador/anuncios_controlador.php">Crear anuncios</a></li>
											<li><a href="Controlador/mis_anuncios_controlador.php">Mis anuncios</a></li>
										</ul>
									</li>
									
									</li>
									
									<li><a class="icon solid fa-cog" href="#"><span>Mensajes</span></a>
										<ul>
											<li><a href="Controlador/mensajes_controlador.php">Propuestas de intercambio</a></li>
											<li><a href="Controlador/mensajes_aceptados_controlador.php">Propuestas aceptadas</a></li>	
										</ul>
									</li>					
									<li><a class="icon solid fa-retweet" href="Controlador/cerrar_sesion_controler.php"><span>Cerrar sesión</span></a></li>
								</ul>
							</nav>

					</div>
				</section>

			<!-- Features -->
				<section id="features">
					<div class="container">
						<header>
							<h2>Anuncios destacados</h2>
						</header>
						<div class="row aln-center">
							<div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
										<?php
											echo '<a href="#" class="image featured"><img src="' . $ruta1 . '" name="foto1" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										
											echo "<input type='hidden' value='$codigo_anuncio1' name ='codigo_anuncio1'>";
										//	echo "<div name=codigo_anuncio1> Codigo Anuncio " . $codigo_anuncio1 . "<br></div>";	
											echo "<h3>$ofrezco1</h3>"
										?>
										</header>	
										<?php
																				
											echo $descripcion1 . "<br>" . "<br>";	
											echo '<button type="submit" name="anuncio1" class="btn btn-info">Ver anuncio</button>';
										?>
									</section>
									<div class="row">
                        <div class="col">
                       
                        </div>
                    </div>

							</div>
							<div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
										<?php
										echo '<a href="#" class="image featured"><img src="' . $ruta2 . '" name="foto2" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio2' name ='codigo_anuncio2'>";
										echo "<h3>$ofrezco2</h3>"
										?>
										</header>
										<?php
										echo $descripcion2 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio2" class="btn btn-info">Ver anuncio</button>';
										?>
									</section>

							</div>
							<div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php
										echo '<a href="#" class="image featured"><img src="' . $ruta3 . '" name="foto2" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio3' name ='codigo_anuncio3'>";
										echo "<h3>$ofrezco3</h3>"
										?>
										</header>
										<?php
										echo $descripcion3 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio3" class="btn btn-info">Ver anuncio</button>';
										?>
                                    </section>                                    
                            </div>

                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php
										echo '<a href="#" class="image featured"><img src="' . $ruta4 . '" name="foto2" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio4' name ='codigo_anuncio4'>";
										echo "<h3>$ofrezco4</h3>"
										?>
										</header>
										<?php
										echo $descripcion4 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio4" class="btn btn-info">Ver anuncio</button>';
										?>
                                    </section>                                    
                            </div>

                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php
										echo '<a href="#" class="image featured"><img src="' . $ruta5 . '" name="foto2" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio5' name ='codigo_anuncio5'>";
										echo "<h3>$ofrezco5</h3>"
										?>
										</header>
										<?php
										echo $descripcion5 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio5" class="btn btn-info">Ver anuncio</button>';
										?>
                                 	</section> 
                            </div>

                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php
										echo '<a href="#" class="image featured"><img src="' . $ruta6 . '" name="foto6" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio6' name ='codigo_anuncio6'>";
										echo "<h3>$ofrezco6</h3>"
										?>
										</header>
										<?php
										echo $descripcion6 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio6" class="btn btn-info">Ver anuncio</button>';
										?>
                                    </section>                                    
                            </div>   
                            
                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php	
										echo '<a href="#" class="image featured"><img src="' . $ruta7 . '" name="foto7" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio7' name ='codigo_anuncio7'>";
										echo "<h3>$ofrezco7</h3>"
										?>
										</header>
										<?php
										echo $descripcion7 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio7 class="btn btn-info">Ver anuncio</button>';
										?>
									</section>	
		
                            </div>    

                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
										<?php	
										echo '<a href="#" class="image featured"><img src="' . $ruta8 . '" name="foto8" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio8' name ='codigo_anuncio8'>";
										echo "<h3>$ofrezco8</h3>"
										?>
										</header>
										<?php
										echo $descripcion8 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio8" class="btn btn-info">Ver anuncio</button>';
										?>
                                    </section>                                    
                            </div>    

                            <div class="col-4 col-6-medium col-12-small">

								<!-- Feature -->
									<section>
									<?php	
										echo '<a href="#" class="image featured"><img src="' . $ruta9 . '" name="foto9" width="250" height="250" alt="" /></a>';
										?>
										<header>
										<?php
										echo "<input type='hidden' value='$codigo_anuncio9' name ='codigo_anuncio9'>";
										echo "<h3>$ofrezco9</h3>"
										?>
										</header>
										<?php
										echo $descripcion9 . "<br>" . "<br>";
										echo '<button type="submit" name="anuncio9" class="btn btn-info">Ver anuncio</button>';
										?>
                                    </section>                                    
                            </div>    
						</div>
					</div>
                </section>


			<!-- Footer -->
				<section id="footer">
					<div class="container">
						<header>
							<h2><strong>Contacta con nosotros</strong></h2>
						</header>
						<div class="row">
							<div class="col-6 col-12-medium">
								<section>
									<form method="post" action="#">
										<div class="row gtr-50">
											<div class="col-6 col-12-small">
												<input name="name" placeholder="Nombre" type="text" />
											</div>
											<div class="col-6 col-12-small">
												<input name="email" placeholder="Email" type="text" />
											</div>
											<div class="col-12">
												<textarea name="message" placeholder="Mensaje"></textarea>
											</div>
											<div class="col-12">
												<a href="#" class="form-button-submit button icon solid fa-envelope">Enviar</a>
											</div>
										</div>
									</form>
								</section>
							</div>
							<div class="col-6 col-12-medium">
								<section>
									<p>Si lo deseas puedes ponerte en contacto con nosotros para cualquier consulta. Déjanos tu Nombre
                                        y tu correo, y nos pondremos en contacto contigo.</p>
									<div class="row">
										<div class="col-6 col-12-small">
											<ul class="icons">
												<li class="icon solid fa-home">
													C/ A nº 1 Bajos<br />
													41000 Sevilla<br />
													España
												</li>
												<li class="icon solid fa-phone">
													(000) 000-0000
												</li>
												<li class="icon solid fa-envelope">
													<a href="#">GranTrueque.tld</a>
												</li>
											</ul>
										</div>
										<div class="col-6 col-12-small">
											<ul class="icons">
												<li class="icon brands fa-twitter">
													<a href="#">GranTrueque@unt</a>
												</li>
												<li class="icon brands fa-instagram">
													<a href="#">instagram.com/GranTrueque</a>
												</li>
												<li class="icon brands fa-dribbble">
													<a href="#">dribbble.com/GranTrueque</a>
												</li>
												<li class="icon brands fa-facebook-f">
													<a href="#">facebook.com/GranTrueque</a>
												</li>
											</ul>
										</div>
									</div>
								</section>
							</div>
						</div>
					</div>
					<div id="copyright" class="container">
						<ul class="links">
							<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
						</ul>
					</div>
				</section>
</form>	
		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>