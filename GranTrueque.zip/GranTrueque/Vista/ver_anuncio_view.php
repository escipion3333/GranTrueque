<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
</head>
<body>
    <?php
    /////////// Comprobamos si el usuario ha abierto sesión /////////
    session_start();
    if (!isset ($_SESSION["usuario"])){
        header("Location:../index.php");
    }
    ?>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Intercambiar productos</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo podrás intercambiar tus productos. Si deseas 
                    realizar el trueque de forma segura pulsa sobre el botón "Trueque seguro"
                </p>
                
                <form action = "../Controlador/principal_controler.php" method="POST">
                  <section>  
                      
                  <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="hidden" name="codigo_anunciante" value="' . $codigo_usuario.'"  readonly id="codigo_anunciante" class="form-control">';  
                            ?>                        
                         </div>              
                    </div>

                    
                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="hidden" name="codigo_anuncio_anunciante" value="' . $codigo_anuncio.'"  readonly id="ofrezco" class="form-control">';  
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="ofrezco" value="' . $ofrezco.'"  readonly id="ofrezco" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="valor" value="' . $valor. ' € " readonly id="valor" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="email" value="' . $email.'"  readonly id="email" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>


                    <?php
                    echo '<a href="#" class="image featured"><img src="' . $ruta . '" name="foto" width="250" height="350" alt="" /></a>';
                    ?>
                    </section>
                    <div class="row">
                        <div class="col">
                            <button type="submit" name="trueque" class="btn btn-info">Trueque seguro</button>
                            <button type="submit" name="menu_principal2" class="btn btn-info">Menú principal</button>
                        </div>
                    </div>
                    
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>