<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión usuarios</title>
    <link rel="stylesheet" href="../Vista/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Vista/css/usuarios.css">
    
</head>
<body>
    <h1 class="cabecera centrar">Gran Trueque</h1>
    <br> <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <h2 class="modulo">Intercambio de productos</h2>
                <hr class= "bg-info">
                <p class="pb-0 mb-0">En este módulo pdrás crear tu cuenta de usuario</p>
                <p class="text-danger small pt-0 mt-0">Todos los campos son obligatorios</p>
                
                <form action = "principal_controler.php" method="POST">
                    <div>
                        <div class="col-md-8">
                            <?php
                            echo '<input type="text" name="ofrezco" value="' . $ofrezco.'"  readonly id="ofrezco" class="form-control">';  
                            echo "<br>";
                            ?>                        
                         </div>              
                    </div>

                    <div>
                        <?php
                        /*
                        echo '<textarea name="descripcion" set_value=("aaa") id="" cols="49" rows="5">' . $descripcion . '</textarea>';                     
                        */
                        ?>
                        <div class="col-md-8">                                            
                        </div>              
                    </div>

                    <div class="col-md-8">
                            <?php
                            echo "<br>";
                            echo '<input type="text" name="valor" value="' . $valor.'"  id="ofrezco" class="form-control">';  
                            ?>                        
                         </div>              
                    </div>
                    <div class="row">
                        <div class="col">
                        <button type="submit" name="modificar" class="btn btn-info">Modificar</button>
                        <button type="submit" name="baja" class="btn btn-info">Dar de baja</button>

                        </div>
                    </div>
                    </div>
                    
                </form>
            </div>              
        </div>
    </div>
   
</body>
</html>