<!DOCTYPE html>  
<meta charset ="utf-8">
<html lang="es">
<head>
<title>    </title>
   <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
   <link rel="stylesheet" href="Vista/assets/css/main.css" />
</head>

<body>

<?php

   require_once "Controlador/principal_controler.php";
?>

</body>
</html>

