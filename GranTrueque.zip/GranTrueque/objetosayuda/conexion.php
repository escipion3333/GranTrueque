<?php

    require ("config.php");

    class Conexion {

        protected $conexion;

        public function Conexion (){

            $this->conexion = new mysqli ('HOST','USUARIO0','CONTRA','BASE');
            
            if ($this->conexion->connect_errno){
                echo "Falllo al conectar";
                return;
            }
            $this->conexion->set_charset(CHARSET);

        }
    }

?>