<?php

try{
    $conexion=new PDO ('mysql:host=localhost; dbname=GranTrueque', 'root','');
    $conexion->exec ("SET CHARACTER SET utf8");
    echo "Conexión realizada con éxito";

}catch (Exception $e){
    die ('Error ' .$e->getMessage());
}finally {
    $conexion=null;
}
?>