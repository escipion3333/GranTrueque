<?php

    // Definimos los datos de conexión como constantes

    define ('HOSTt','localhost');
    define ('USUARIO', 'root');
    define ('CONTRA', '');
    define ('BASE', 'GranTrueque');
    define ('CHARSET','utf8');

?>