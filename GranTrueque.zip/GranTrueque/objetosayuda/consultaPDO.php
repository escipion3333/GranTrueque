<?php

try{
    $conexion=new PDO ('mysql:host=localhost; dbname=GranTrueque', 'root','');
    $conexion->exec ("SET CHARACTER SET utf8");
    echo "Conexión realizada con éxito";

    // Preparamos la consulta preparada
    $consulta = ("SELECT CodigoCategoria, DescripcionCategoria FROM Categorías where DescripcionCategoria =?");
    $resultado = $conexion->prepare($consulta);
    $resultado->execute (array("MESAS"));
    while ($fila=$resultado->fetch (PDO::FETCH_ASSOC)){
        echo "Código Categoría " . $fila['CodigoCategoria'] . "Descripcion " . $fila['DescripcionCategoria'];
    }
    $resultado->closeCursor();

}catch (Exception $e){
    die ('Error ' .$e->getMessage());
}finally {
    $conexion=null;
}

?>