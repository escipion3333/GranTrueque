<?php

    require("coneion.php");

    class DevuelveProductos extends conexion {

        public function DevuelveProducto (){

            // Llamamos al contructor de la clase padre

            parent:: Conexion();
        }

        public function getProducots(){
            $resultado = $this->conexion->query('SELECT * FROM CodigosPostales');
            $productos = $resultado->fetch_all(MYSQLI_ASSOC);
            return $productos;
        }


    }

?>